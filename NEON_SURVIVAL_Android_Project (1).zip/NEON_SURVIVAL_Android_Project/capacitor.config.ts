import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.neonsurvival.game',
  appName: 'NEON SURVIVAL',
  webDir: 'www',
  bundledWebRuntime: false,
  android: {
    backgroundColor: '#090b1d'
  }
};

export default config;

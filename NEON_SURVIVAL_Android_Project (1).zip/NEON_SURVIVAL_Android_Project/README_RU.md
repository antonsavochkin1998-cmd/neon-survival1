# NEON SURVIVAL — Android APK project

Это Android-оболочка для игры NEON SURVIVAL. Сама игра находится в `www/index.html`.
Проект использует Capacitor и собирается в бесплатных инструментах.

## Что нужно
- Компьютер Windows / macOS / Linux (собирать APK на самом Android-телефоне этим способом неудобно).
- Node.js LTS (рекомендуется Node 20 или новее).
- Android Studio (бесплатно для этой задачи).
- Android SDK, который Android Studio предложит установить.

## Сборка APK

1. Распакуйте архив в отдельную папку.
2. Установите Node.js и Android Studio.
3. Откройте терминал в папке `neon_survival_android`.
4. Выполните команды по очереди:

   ```bash
   npm install
   npx cap add android
   npx cap sync android
   npx cap open android
   ```

   Если папка `android` уже создана, пропустите `npx cap add android`.

5. В Android Studio дождитесь окончания Gradle Sync.
6. Подключите Android-телефон по USB и включите «Для разработчиков» → «Отладка по USB».
7. Для установки и теста нажмите зелёную кнопку Run.

## Получить APK-файл

Для тестовой установки:
- В Android Studio откройте **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
- После сборки нажмите **locate** в уведомлении.
- Обычно APK находится здесь: `android/app/build/outputs/apk/debug/app-debug.apk`.

Или в терминале из папки проекта:
- Windows: `cd android` затем `gradlew.bat assembleDebug`
- macOS/Linux: `cd android` затем `./gradlew assembleDebug`

## Важные замечания

- APK — это устанавливаемое приложение, но этот проект пока не публикует игру в Google Play.
- Для публикации в Google Play понадобится отдельная настройка релизной подписи и соблюдение актуальных требований Google Play.
- Сохранения игры используют локальное хранилище WebView на устройстве. Не очищайте данные приложения, если хотите сохранить прогресс.
- Игровой код уже включён. Интернет для самой игры не нужен после установки.
- В текущей версии есть звуковые эффекты-сигналы; полноценный фоновый музыкальный трек ещё не добавлен.
- Для сборки APK нужен компьютер с Android Studio. На одном телефоне можно редактировать HTML, но полноценная сборка Android-проекта таким способом не гарантируется.

## Где менять игру
Редактируйте `www/index.html`. После изменений выполните:

```bash
npx cap sync android
```

Затем снова соберите APK в Android Studio.
